package com.heritage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HeritageMigrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
